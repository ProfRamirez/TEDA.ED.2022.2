#include <iostream>

using namespace std;

class ListaD;
class NoD
{
    int dado;

    NoD * prox, *anterior;
public:
    NoD(int p_dado) : dado(p_dado) { prox = anterior = nullptr; }
    friend ListaD;
};
class ListaD
{
    NoD *inicio, *fim;

public:
    ListaD() { inicio = fim = nullptr; }
    void InsereFim(int d);
    void Print(void);
    void PrintReverso(void);
};

void ListaD::InsereFim(int d)
{
    NoD * aux = new NoD(d);

    if (inicio) {
        fim->prox = aux;
        aux->anterior = fim;
        fim = aux;
    } else {
        inicio = fim = aux;
    }
}

void ListaD::Print(void)
{
    for( NoD * aux = inicio; aux; aux = aux->prox)
        cout << aux->dado << endl;
}

void ListaD::PrintReverso(void)
{
    for( NoD * aux = fim; aux; aux = aux->anterior)
        cout << aux->dado << endl;
}

int main()
{
    cout << "Exemplo de Lista Dupla" << endl;

    ListaD listaDupla;
    for( int i = 0; i < 10; i++)
        listaDupla.InsereFim(i);
    listaDupla.Print();
    listaDupla.PrintReverso();

    return 0;
}
