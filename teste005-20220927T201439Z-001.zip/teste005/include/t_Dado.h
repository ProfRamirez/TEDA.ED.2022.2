#ifndef T_DADO_H
#define T_DADO_H

#include <iostream>
using namespace std;

class t_Dado
{
    public:
        t_Dado();
        t_Dado(int ip) { i = ip;}
        virtual ~t_Dado();
        int Get(void) { return i; }
        void Put(int p_i) { i = p_i; }
        void Print(void) { cout << i << endl; }

    protected:

    private:
        int i; // CHAVE Prim�ria
};

#endif // T_DADO_H
