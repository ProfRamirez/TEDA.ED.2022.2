#ifndef T_LISTA_H
#define T_LISTA_H

#include "t_No.h"

class t_Lista
{
    public:
        t_Lista();
        virtual ~t_Lista();
        void Put(t_No *ptr_novo);
        void Put(t_Dado d);
        void Print(void);
        t_No *topo;

    protected:

    private:
//        t_No *topo;
        t_No *fim;
        unsigned int length;
};

#endif // T_LISTA_H
