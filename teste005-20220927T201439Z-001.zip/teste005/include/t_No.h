#ifndef T_NO_H
#define T_NO_H

#include "t_Dado.h"

class t_No
{
    public:
        t_No *prox; // campo de liga��o

        t_No(t_Dado);
        t_No() { prox = nullptr; }
        virtual ~t_No() { delete prox; }
        void Put(t_Dado d) { dado = d; }
        t_Dado Get(void) { return dado; }

    protected:

    private:
        t_Dado dado;
};

#endif // T_NO_H
