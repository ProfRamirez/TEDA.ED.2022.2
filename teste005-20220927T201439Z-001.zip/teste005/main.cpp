#include <iostream>

#include "t_Dado.h"
#include "t_Lista.h"

using namespace std;

void RunTeste(void)
{
    t_Dado d;
    t_Lista lst1;

    for(int i= 0; i < 10; i++)
    {
        d.Put(i);
        lst1.Put(d);
    }
    lst1.Print();
    lst1.topo->prox->prox->Put(t_Dado(33));
    lst1.Print();
}

int main()
{
    cout << "Teste005: 1a implementa��o da listas simples" << endl;

    RunTeste();
    return 0;
}
