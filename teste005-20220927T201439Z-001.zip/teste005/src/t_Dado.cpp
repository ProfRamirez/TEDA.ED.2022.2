#include "t_Dado.h"

t_Dado::t_Dado()
{
    //ctor
}

t_Dado::~t_Dado()
{
    //dtor
}
