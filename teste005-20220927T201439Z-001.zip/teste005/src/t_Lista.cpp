#include "t_Lista.h"

#include <iostream>
using namespace std;

t_Lista::t_Lista()
{
    //ctor
    topo = nullptr;
    fim = nullptr;
    length = 0; // lista inicia vazia
}

t_Lista::~t_Lista()
{
    //dtor
}

void t_Lista::Put(t_No *ptr_novo)
{
    if ( topo == nullptr )
        topo = ptr_novo;
    else
        fim->prox = ptr_novo;
    fim = ptr_novo;
}

void t_Lista::Put(t_Dado d)
{
    t_No *ptr_novo = new t_No(d);
    Put(ptr_novo);
}

void t_Lista::Print(void)
{
    t_No *aux;

    aux = topo;
    while( aux )
    {
        cout << (aux->Get()).Get() << endl;
        aux = aux->prox;
    }
}
