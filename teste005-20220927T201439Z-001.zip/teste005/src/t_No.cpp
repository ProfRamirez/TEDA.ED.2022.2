#include "t_No.h"

t_No::t_No(t_Dado d)
{
   dado = d;
   prox = nullptr;
}
