#include <fstream>
#include <iostream>

using namespace std;

class ListaD;
struct t_Ponto { int x; int y;};
class NoD
{
     t_Ponto dado;

    NoD * prox, *anterior;
public:
    NoD(t_Ponto p_dado) : dado(p_dado) { prox = anterior = nullptr; }
    t_Ponto GetDado(void) { return dado; }
    friend ListaD;
};
class ListaD
{
    NoD *inicio, *fim;

public:
    ListaD() { inicio = fim = nullptr; }
    void InsereFim(NoD *);
    NoD * DeletaFim(void);
    void Print(void);
    void PrintReverso(void);
};

void ListaD::InsereFim(NoD * aux)
{
//    NoD * aux = new NoD(d);

    if (inicio) {
        fim->prox = aux;
        aux->anterior = fim;
        fim = aux;
    } else {
        inicio = fim = aux;
    }
}

NoD * ListaD::DeletaFim(void)
{
    NoD * aux;

    if (fim) {
        aux = fim;
        if (inicio != fim)
        {
            fim->anterior->prox = nullptr;
            fim = fim->anterior;
            return aux;;
        }
        else
            inicio = fim = nullptr;
    } else {
        return nullptr; // lista vazia
    }
}

void ListaD::Print(void)
{
    for( NoD * aux = inicio; aux; aux = aux->prox)
        cout << aux->dado.x << " | ";
    cout << endl;
}

void ListaD::PrintReverso(void)
{
    for( NoD * aux = fim; aux; aux = aux->anterior)
        cout << aux->dado.x << " | ";
    cout << endl;
}
/*----------------------------------
 * Pilha com Lista Dupla
 *----------------------------------
 */
ListaD pilhaL;

void PushL(t_Ponto dado)
{
    NoD * aux;

    try
    {
        aux = new NoD(dado);
    }
    catch (std::exception& e)
    {
        std::cerr << "Pilha cheia por falta de mem�ria! " << e.what() << '\n';
    }
    pilhaL.InsereFim(aux);
}

t_Ponto PopL(void)
{
    NoD * aux;

    aux = pilhaL.DeletaFim();
    if ( aux != nullptr )
        return aux->GetDado();
    else
        cout << "Pilha vazia" << endl; // underflow
}

void PrintPilhaL(void)
{
    pilhaL.Print();
}

/*----------------------------------
 * Pilha com array
 *----------------------------------
 */

int pilha[100];
int pos_topo_pilha = 0;

void Push(int dado)
{
    if (pos_topo_pilha != 100)
        pilha[pos_topo_pilha++] = dado;
    else
        cout << "Pilha cheia" << endl; // overflow
}

int Pop(void)
{
    if (pos_topo_pilha != 0)
        return pilha[--pos_topo_pilha];
    else
        cout << "Pilha vazia" << endl; // underflow
}

void PrintPilha(void)
{
    cout << "Pilha: ";
    for ( int i = 0; i < pos_topo_pilha; i++)
        //cout << pilha[i] << " | ";
    cout << endl;
}

string linha[10];

void Preenche(int lin, int col, char marca)
{
    char c;

    c = linha[lin][col];
    if ( c != '1' && c != marca )
    {
        linha[lin][col] = marca;
        c = linha[lin-1][col];
        if ( c != '1' && c != marca ) Preenche(lin-1,col,marca);
        c = linha[lin+1][col];
        if ( c != '1' && c != marca ) Preenche(lin+1,col,marca);
        c = linha[lin][col+1];
        if ( c != '1' && c != marca ) Preenche(lin,col+1,marca);
        c = linha[lin][col-1];
        if ( c != '1' && c != marca ) Preenche(lin,col-1,marca);
    }
}

void PreenchePilha(int lin, int col, char marca)
{
    char c;
    t_Ponto pnt;

    c = linha[lin][col];
    if ( c != '1' && c != marca )
    {
        pnt.x = col; pnt.y = lin;
        PushL(pnt);
    }

//#define ever ;;
    t_Ponto aux;
    for(;;)
    {
        pnt = PopL();
        if (aux == nullptr ) break;

        pnt = aux->dado;
        lin = pnt.y; col = pnt.x;
        linha[lin][col] = marca;
        c = linha[lin-1][col];
        if ( c != '1' && c != marca ) { pnt.y = lin-1; pnt.x = col; PushL(pnt); }
        c = linha[lin+1][col];
        if ( c != '1' && c != marca ) { pnt.y = lin+1; pnt.x = col; PushL(pnt); }
        c = linha[lin][col+1];
        if ( c != '1' && c != marca ) { pnt.y = lin; pnt.x = col+1; PushL(pnt); }
        c = linha[lin][col-1];
        if ( c != '1' && c != marca ) { pnt.y = lin; pnt.x = col-1; PushL(pnt); }
    }
}


int main()
{
    int v;
    ifstream arq_labirinto;

    cout << "Exemplo de Pilha" << endl;

    arq_labirinto.open("labirinto.txt");
    int i=0;
    while ( !arq_labirinto.eof() )
    {
        getline(arq_labirinto, linha[i]);
        cout << linha[i++] << endl;
    }
    cout << i << endl;
    arq_labirinto.close();

    for(int i = 0; i < 9; i++ )
        cout << linha[i] << endl;
    PreenchePilha(3,2,'@');
    for(int i = 0; i < 9; i++ )
        cout << linha[i] << endl;

    return 0;
}
